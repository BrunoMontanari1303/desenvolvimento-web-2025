const Saudacao = ({ nome }) => {
  return <h1>Bem-vindo, {nome}!</h1>;
};

export default Saudacao;